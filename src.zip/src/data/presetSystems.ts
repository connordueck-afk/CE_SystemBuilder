import type { SystemDesign } from '../types/system';
import { DEFAULT_SYSTEM } from './defaultSystem';

export interface SystemPreset {
  id: string;
  name: string;
  description: string;
  voltage: 12 | 24 | 48;
  tags: string[];
  system: SystemDesign;
}

// ----------------------------------------------------------
// Active validation catalogue is 48 V only (see CODEX_SYSTEM_DESIGN_ENGINE_REFACTOR.md
// and PROJECT_DEFINITION.md). The legacy 12 V / 24 V presets referenced products that
// now live under src/data/products/legacy/ and are no longer loaded, so they were
// removed. The single active preset is the 48 V off-grid cabin, built from the
// known-good DEFAULT_SYSTEM so it always references in-catalogue products.
// ----------------------------------------------------------
const OFFGRID_48V: SystemDesign = {
  id: "sys-1782601911488-2",
  name: "48V Off-Grid Cabin",
  nominalVoltage: 48,
  assumptions: {
    inverterEfficiency: 0.92,
    defaultOemDiscountPercent: 30,
    defaultCableLengthFt: 6,
    maxVoltageDropPercent: 3,
    continuousLoadMultiplier: 1.25,
    batteryInterconnectMaxLengthFt: 3
  },
  createdAt: "2026-06-27T23:11:51.488Z",
  updatedAt: "2026-06-27T23:13:09.505Z",
  components: [
    {
      id: "comp-1782601913910-3",
      productId: "discover-helios-ess-52-48-16000",
      label: "HELIOS ESS 52-48-16000",
      quantity: 1,
      x: -120,
      y: 60,
      includeInBom: true,
      imageScale: 2
    },
    {
      id: "comp-1782601920117-5",
      productId: "discover-helios-ess-52-48-16000",
      label: "HELIOS ESS 52-48-16000 Copy",
      quantity: 1,
      x: 120,
      y: 60,
      includeInBom: true,
      imageScale: 2,
      locked: false
    },
    {
      id: "comp-1782601924842-6",
      productId: "dist-generic-busbar-5pt",
      label: "Generic Busbar 5-point",
      quantity: 1,
      x: -200,
      y: -260,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "negative",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "comp-1782601933494-7",
      productId: "dist-generic-busbar-5pt",
      label: "Generic Busbar 5-point Copy",
      quantity: 1,
      x: 120,
      y: -260,
      includeInBom: true,
      locked: false,
      inferredElectricalType: "dc_pos",
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "comp-1782601958053-19",
      productId: "acc-dc-load-generic",
      label: "DC Load (generic)",
      quantity: 1,
      x: 440,
      y: -380,
      includeInBom: true,
      instanceVoltageV: 48,
      instanceMaxCurrentA: 50
    },
    {
      id: "comp-1782601986453-646",
      productId: "fuse-midi-70a",
      label: "Fuse",
      quantity: 1,
      x: 172,
      y: -135,
      rotationDeg: 270,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "comp-1782601989501-655",
      productId: "fuse-midi-70a",
      label: "Fuse 2",
      quantity: 1,
      x: 193,
      y: -390,
      rotationDeg: 180,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    }
  ],
  connections: [
    {
      id: "conn-1782601937475-8",
      fromComponentId: "comp-1782601913910-3",
      fromTerminalId: "dc_pos_1",
      toComponentId: "comp-1782601920117-5",
      toTerminalId: "dc_pos_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -8,
          y: -64
        },
        {
          x: -8,
          y: -110
        },
        {
          x: 196,
          y: -110
        }
      ],
      routeMode: "manual",
      busType: "dc_pos",
      calculatedCurrentA: 50,
      recommendedFuseA: 70,
      recommendedCableAwg: "8",
      voltageDropV: 0.126,
      voltageDropPercent: 0.25,
      warnings: []
    },
    {
      id: "conn-1782601941176-10",
      fromComponentId: "comp-1782601920117-5",
      fromTerminalId: "dc_neg_1",
      toComponentId: "comp-1782601913910-3",
      toTerminalId: "dc_neg_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: 8,
          y: -64
        },
        {
          x: 8,
          y: -50
        }
      ],
      routeMode: "auto",
      busType: "dc_neg",
      calculatedCurrentA: 50,
      recommendedCableAwg: "8",
      voltageDropV: 0.126,
      voltageDropPercent: 0.25,
      warnings: []
    },
    {
      id: "conn-1782601942551-11",
      fromComponentId: "comp-1782601913910-3",
      fromTerminalId: "dc_neg_1",
      toComponentId: "comp-1782601924842-6",
      toTerminalId: "terminal_1",
      cableLengthFt: 6,
      routePoints: [
        {
          x: -252,
          y: -64
        }
      ],
      routeMode: "auto",
      busType: "dc_neg",
      calculatedCurrentA: 70,
      recommendedCableAwg: "6",
      voltageDropV: 0.332,
      voltageDropPercent: 0.65,
      warnings: []
    },
    {
      id: "conn-1782601944675-12",
      fromComponentId: "comp-1782601913910-3",
      fromTerminalId: "port_lynk_2",
      toComponentId: "comp-1782601920117-5",
      toTerminalId: "port_lynk_1",
      cableLengthFt: 6,
      wireKind: "communication",
      busType: "communication",
      calculatedCurrentA: 0,
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: []
    },
    {
      id: "conn-1782601962568-117",
      fromComponentId: "comp-1782601958053-19",
      fromTerminalId: "dc_neg",
      toComponentId: "comp-1782601924842-6",
      toTerminalId: "terminal_5",
      cableLengthFt: 6,
      routePoints: [
        {
          x: -148,
          y: -370
        }
      ],
      routeMode: "auto",
      busType: "dc_neg",
      calculatedCurrentA: 50,
      recommendedCableAwg: "8",
      voltageDropV: 0.377,
      voltageDropPercent: 0.79,
      warnings: []
    },
    {
      id: "conn-1782601986454-647",
      fromComponentId: "comp-1782601920117-5",
      fromTerminalId: "dc_pos_1",
      toComponentId: "comp-1782601986453-646",
      toTerminalId: "in",
      cableLengthFt: 3,
      routePoints: [
        {
          x: 172,
          y: -64
        }
      ],
      busType: "dc_pos",
      calculatedCurrentA: 50,
      recommendedFuseA: 70,
      recommendedCableAwg: "8",
      voltageDropV: 0.189,
      voltageDropPercent: 0.37,
      warnings: []
    },
    {
      id: "conn-1782601986454-648",
      fromComponentId: "comp-1782601986453-646",
      fromTerminalId: "out",
      toComponentId: "comp-1782601933494-7",
      toTerminalId: "terminal_5",
      cableLengthFt: 3,
      busType: "dc_pos",
      calculatedCurrentA: 50,
      recommendedFuseA: 70,
      recommendedCableAwg: "8",
      voltageDropV: 0.189,
      voltageDropPercent: 0.39,
      warnings: []
    },
    {
      id: "conn-1782601989501-656",
      fromComponentId: "comp-1782601958053-19",
      fromTerminalId: "dc_pos",
      toComponentId: "comp-1782601989501-655",
      toTerminalId: "in",
      cableLengthFt: 3,
      busType: "dc_pos",
      calculatedCurrentA: 50,
      recommendedFuseA: 70,
      recommendedCableAwg: "8",
      voltageDropV: 0.189,
      voltageDropPercent: 0.39,
      warnings: []
    },
    {
      id: "conn-1782601989501-657",
      fromComponentId: "comp-1782601989501-655",
      fromTerminalId: "out",
      toComponentId: "comp-1782601933494-7",
      toTerminalId: "terminal_4",
      cableLengthFt: 3,
      routePoints: [
        {
          x: 146,
          y: -390
        }
      ],
      busType: "dc_pos",
      calculatedCurrentA: 50,
      recommendedFuseA: 70,
      recommendedCableAwg: "8",
      voltageDropV: 0.189,
      voltageDropPercent: 0.39,
      warnings: []
    }
  ],
  annotations: []
};

export const SYSTEM_PRESETS: SystemPreset[] = [
  {
    id: 'offgrid-48v',
    name: '48V Off-Grid Cabin',
    description:
      'Two Discover Helios ESS batteries in parallel, a solar array + MPPT, a 5 kW inverter/charger, and generator backup for a permanent installation.',
    voltage: 48,
    tags: ['48V', 'Cabin', 'Off-Grid', 'Solar', 'Generator', 'Helios'],
    system: OFFGRID_48V,
  },
];

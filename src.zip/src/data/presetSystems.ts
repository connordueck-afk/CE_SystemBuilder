import type { SystemDesign } from '../types/system';
import { DEFAULT_SYSTEM } from './defaultSystem';

export interface SystemPreset {
  id: string;
  name: string;
  description: string;
  voltage: 12 | 24 | 48;
  tags: string[];
  system: SystemDesign;
}

// ----------------------------------------------------------
// Default-system slots used by the reset/new-system menu and the dev-only
// "Set Default" writer. The small/mobile slots are intentionally lightweight
// scaffolds until they are authored from the canvas.
// ----------------------------------------------------------
const SIMPLE_12V: SystemDesign = {
  id: "sys-1782677616826-1",
  name: "48V Off-Grid Cabin",
  nominalVoltage: 48,
  assumptions: {
    inverterEfficiency: 0.92,
    defaultOemDiscountPercent: 30,
    defaultCableLengthFt: 6,
    maxVoltageDropPercent: 3,
    continuousLoadMultiplier: 1.25,
    batteryInterconnectMaxLengthFt: 3
  },
  createdAt: "2026-06-28T20:13:36.826Z",
  updatedAt: "2026-06-28T20:17:11.416Z",
  components: [
    {
      id: "comp-1782677621992-2",
      productId: "discover-helios-ess-52-48-16000",
      label: "HELIOS ESS 52-48-16000",
      quantity: 1,
      x: 80,
      y: 340,
      includeInBom: true,
      imageScale: 2
    },
    {
      id: "comp-1782677671538-9",
      productId: "discover-helios-ess-52-48-16000",
      label: "HELIOS ESS 52-48-16000 Copy",
      quantity: 1,
      x: -120,
      y: 340,
      includeInBom: true,
      imageScale: 2,
      locked: false
    },
    {
      id: "comp-1782677705858-13",
      productId: "discover-helios-ess-52-48-16000",
      label: "HELIOS ESS 52-48-16000 Copy Copy",
      quantity: 1,
      x: -320,
      y: 340,
      includeInBom: true,
      imageScale: 2,
      locked: false
    },
    {
      id: "comp-1782677787656-18",
      productId: "acc-dc-load-generic",
      label: "DC Load (generic)",
      quantity: 1,
      x: 260,
      y: 20,
      includeInBom: true,
      instanceVoltageV: 48,
      instanceMaxCurrentA: 150
    },
    {
      id: "comp-1782677820985-21",
      productId: "fuse-midi-200a",
      label: "Fuse",
      quantity: 1,
      x: 170,
      y: 95,
      rotationDeg: 270,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    }
  ],
  connections: [
    {
      id: "conn-1782677711809-14",
      fromComponentId: "comp-1782677705858-13",
      fromTerminalId: "dc_pos_1",
      toComponentId: "comp-1782677671538-9",
      toTerminalId: "dc_pos_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -230,
          y: 216
        },
        {
          x: -230,
          y: 180
        },
        {
          x: -30,
          y: 180
        },
        {
          x: -30,
          y: 230
        }
      ],
      routeMode: "manual",
      busType: "dc_pos",
      calculatedCurrentA: 150,
      recommendedFuseA: 200,
      recommendedCableAwg: "1/0",
      voltageDropV: 0.059,
      voltageDropPercent: 0.12,
      warnings: []
    },
    {
      id: "conn-1782677712997-15",
      fromComponentId: "comp-1782677671538-9",
      fromTerminalId: "dc_pos_1",
      toComponentId: "comp-1782677621992-2",
      toTerminalId: "dc_pos_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -30,
          y: 216
        },
        {
          x: -30,
          y: 180
        },
        {
          x: 170,
          y: 180
        },
        {
          x: 170,
          y: 230
        }
      ],
      routeMode: "manual",
      busType: "dc_pos",
      calculatedCurrentA: 150,
      recommendedFuseA: 200,
      recommendedCableAwg: "1/0",
      voltageDropV: 0.059,
      voltageDropPercent: 0.12,
      warnings: []
    },
    {
      id: "conn-1782677714730-16",
      fromComponentId: "comp-1782677621992-2",
      fromTerminalId: "dc_neg_1",
      toComponentId: "comp-1782677671538-9",
      toTerminalId: "dc_neg_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -10,
          y: 216
        },
        {
          x: -10,
          y: 150
        },
        {
          x: -210,
          y: 150
        },
        {
          x: -210,
          y: 230
        }
      ],
      routeMode: "manual",
      busType: "dc_neg",
      calculatedCurrentA: 150,
      recommendedCableAwg: "1",
      voltageDropV: 0.074,
      voltageDropPercent: 0.15,
      warnings: []
    },
    {
      id: "conn-1782677716262-17",
      fromComponentId: "comp-1782677671538-9",
      fromTerminalId: "dc_neg_1",
      toComponentId: "comp-1782677705858-13",
      toTerminalId: "dc_neg_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -210,
          y: 216
        },
        {
          x: -210,
          y: 150
        },
        {
          x: -410,
          y: 150
        },
        {
          x: -410,
          y: 230
        }
      ],
      routeMode: "manual",
      busType: "dc_neg",
      calculatedCurrentA: 150,
      recommendedCableAwg: "1",
      voltageDropV: 0.074,
      voltageDropPercent: 0.15,
      warnings: []
    },
    {
      id: "conn-1782677801296-20",
      fromComponentId: "comp-1782677705858-13",
      fromTerminalId: "dc_neg_1",
      toComponentId: "comp-1782677787656-18",
      toTerminalId: "dc_neg",
      cableLengthFt: 6,
      routePoints: [
        {
          x: -410,
          y: 216
        },
        {
          x: -410,
          y: 30
        }
      ],
      routeMode: "manual",
      busType: "dc_neg",
      calculatedCurrentA: 150,
      recommendedCableAwg: "1/0",
      voltageDropV: 0.177,
      voltageDropPercent: 0.35,
      warnings: []
    },
    {
      id: "conn-1782677820985-24",
      fromComponentId: "comp-1782677787656-18",
      fromTerminalId: "dc_pos",
      toComponentId: "comp-1782677820985-21",
      toTerminalId: "out",
      cableLengthFt: 3,
      routePoints: [
        {
          x: 170,
          y: 10
        }
      ],
      busType: "dc_pos",
      calculatedCurrentA: 150,
      recommendedFuseA: 200,
      recommendedCableAwg: "1/0",
      voltageDropV: 0.088,
      voltageDropPercent: 0.18,
      warnings: []
    },
    {
      id: "conn-1782677820985-25",
      fromComponentId: "comp-1782677820985-21",
      fromTerminalId: "in",
      toComponentId: "comp-1782677621992-2",
      toTerminalId: "dc_pos_1",
      cableLengthFt: 3,
      routePoints: [
        {
          x: 170,
          y: 216
        }
      ],
      busType: "dc_pos",
      calculatedCurrentA: 150,
      recommendedFuseA: 200,
      recommendedCableAwg: "1/0",
      voltageDropV: 0.088,
      voltageDropPercent: 0.17,
      warnings: []
    }
  ],
  annotations: []
};

const FULL_12V: SystemDesign = {
  id: 'preset-full-12v',
  name: 'Full 12V Mobile',
  nominalVoltage: 12,
  assumptions: { ...DEFAULT_SYSTEM.assumptions },
  createdAt: '2026-06-28T00:00:00.000Z',
  updatedAt: '2026-06-28T00:00:00.000Z',
  components: [],
  connections: [],
  annotations: [],
};

const OFFGRID_48V: SystemDesign = {
  id: "sys-1782765873415-1",
  name: "48V Hybrid Off-Grid Cabin",
  nominalVoltage: 48,
  assumptions: {
    inverterEfficiency: 0.92,
    defaultOemDiscountPercent: 30,
    defaultCableLengthFt: 6,
    maxVoltageDropPercent: 3,
    continuousLoadMultiplier: 1.25,
    batteryInterconnectMaxLengthFt: 3
  },
  createdAt: "2026-06-29T20:44:33.415Z",
  updatedAt: "2026-06-29T20:44:40.192Z",
  components: [
    {
      id: "bat-1",
      productId: "discover-helios-ess-52-48-16000",
      label: "Helios ESS 1",
      quantity: 1,
      x: 40,
      y: 580,
      includeInBom: true,
      imageScale: 2,
      configuredProtocols: {
        can_out: "Pylon LV"
      }
    },
    {
      id: "bat-2",
      productId: "discover-helios-ess-52-48-16000",
      label: "Helios ESS 2",
      quantity: 1,
      x: -160,
      y: 580,
      includeInBom: true,
      imageScale: 2
    },
    {
      id: "bat-3",
      productId: "discover-helios-ess-52-48-16000",
      label: "Helios ESS 3",
      quantity: 1,
      x: -360,
      y: 580,
      includeInBom: true,
      imageScale: 2,
      configuredProtocols: {
        can_out: "Pylon LV"
      }
    },
    {
      id: "inverter",
      productId: "megarevo-12kw-hybrid-inverter",
      label: "Megarevo Hybrid Inverter",
      quantity: 1,
      x: 20,
      y: 100,
      includeInBom: true
    },
    {
      id: "grid-source",
      productId: "generic-grid-source-240v",
      label: "AC Source",
      quantity: 1,
      x: 520,
      y: -100,
      includeInBom: true,
      rotationDeg: 180,
      instanceMaxCurrentA: 30
    },
    {
      id: "grid-breaker",
      productId: "breaker-ac-din-2p-63a",
      label: "Grid Input Breaker",
      quantity: 1,
      x: 260,
      y: 100,
      includeInBom: true
    },
    {
      id: "generator-source",
      productId: "generic-generator-source-240v",
      label: "Generator Source",
      quantity: 1,
      x: 520,
      y: 0,
      includeInBom: true,
      rotationDeg: 180,
      instanceMaxCurrentA: 30
    },
    {
      id: "generator-breaker",
      productId: "breaker-ac-din-2p-63a",
      label: "Generator Input Breaker",
      quantity: 1,
      x: 340,
      y: 100,
      includeInBom: true,
      rotationDeg: 0
    },
    {
      id: "load-breaker",
      productId: "breaker-ac-din-2p-50a",
      label: "Critical Loads Breaker",
      quantity: 1,
      x: 340,
      y: 400,
      includeInBom: true
    },
    {
      id: "ac-load",
      productId: "acc-ac-load-split-phase-240v",
      label: "AC Loads",
      quantity: 1,
      x: 520,
      y: 520,
      includeInBom: true
    },
    {
      id: "comp-1782758496710-223",
      productId: "solar-array-400w",
      label: "Solar Panel 400W",
      quantity: 1,
      x: -500,
      y: -300,
      includeInBom: true
    },
    {
      id: "comp-1782758499526-398",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy",
      quantity: 1,
      x: -360,
      y: -300,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758500854-585",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy",
      quantity: 1,
      x: -220,
      y: -300,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758508062-964",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy Copy",
      quantity: 1,
      x: -640,
      y: -300,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758512086-1271",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy Copy Copy",
      quantity: 1,
      x: -80,
      y: -300,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758514118-1494",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy Copy Copy Copy",
      quantity: 1,
      x: -780,
      y: -300,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758544710-3013",
      productId: "solar-array-400w",
      label: "Solar Panel 400W",
      quantity: 1,
      x: -500,
      y: -160,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758544710-3014",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy",
      quantity: 1,
      x: -360,
      y: -160,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758544710-3015",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy",
      quantity: 1,
      x: -220,
      y: -160,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758544710-3016",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy Copy",
      quantity: 1,
      x: -640,
      y: -160,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758544710-3017",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy Copy Copy",
      quantity: 1,
      x: -80,
      y: -160,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782758544710-3018",
      productId: "solar-array-400w",
      label: "Solar Panel 400W Copy Copy Copy Copy Copy",
      quantity: 1,
      x: -780,
      y: -160,
      includeInBom: true,
      locked: false
    },
    {
      id: "comp-1782765880160-14",
      productId: "fuse-anl-325a",
      label: "Fuse",
      quantity: 1,
      x: 26.5,
      y: 380,
      rotationDeg: 180,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    }
  ],
  connections: [
    {
      id: "grid-l1",
      fromComponentId: "grid-source",
      fromTerminalId: "ac_l1",
      toComponentId: "grid-breaker",
      toTerminalId: "l1_in",
      cableLengthFt: 10,
      busType: "ac_line",
      calculatedCurrentA: 30,
      recommendedFuseA: 40,
      recommendedCableAwg: "8",
      voltageDropV: 0.377,
      voltageDropPercent: 0.16,
      warnings: []
    },
    {
      id: "grid-l2",
      fromComponentId: "grid-source",
      fromTerminalId: "ac_l2",
      toComponentId: "grid-breaker",
      toTerminalId: "l2_in",
      cableLengthFt: 10,
      busType: "ac_line2",
      calculatedCurrentA: 30,
      recommendedFuseA: 40,
      recommendedCableAwg: "8",
      voltageDropV: 0.377,
      voltageDropPercent: 0.16,
      warnings: []
    },
    {
      id: "grid-breaker-inverter-l1",
      fromComponentId: "grid-breaker",
      fromTerminalId: "l1_out",
      toComponentId: "inverter",
      toTerminalId: "ac_grid_l1",
      cableLengthFt: 6,
      busType: "ac_line",
      calculatedCurrentA: 0,
      recommendedCableAwg: "8",
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: [],
      routePoints: [
        {
          x: 247.4,
          y: 260
        },
        {
          x: -12,
          y: 260
        }
      ],
      routeMode: "manual"
    },
    {
      id: "grid-breaker-inverter-l2",
      fromComponentId: "grid-breaker",
      fromTerminalId: "l2_out",
      toComponentId: "inverter",
      toTerminalId: "ac_grid_l2",
      cableLengthFt: 6,
      busType: "ac_line2",
      calculatedCurrentA: 0,
      recommendedCableAwg: "8",
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: [],
      routePoints: [
        {
          x: 272.6,
          y: 270
        },
        {
          x: -1,
          y: 270
        }
      ],
      routeMode: "manual"
    },
    {
      id: "grid-neutral",
      fromComponentId: "grid-source",
      fromTerminalId: "ac_n",
      toComponentId: "inverter",
      toTerminalId: "ac_grid_n",
      cableLengthFt: 10,
      busType: "ac_neutral",
      calculatedCurrentA: 30,
      recommendedCableAwg: "12",
      voltageDropV: 0.953,
      voltageDropPercent: 0.4,
      warnings: [],
      routePoints: [
        {
          x: 232,
          y: -84
        },
        {
          x: 232,
          y: 250
        },
        {
          x: -6,
          y: 250
        }
      ],
      routeMode: "manual"
    },
    {
      id: "gen-l1",
      fromComponentId: "generator-source",
      fromTerminalId: "ac_l1",
      toComponentId: "generator-breaker",
      toTerminalId: "l1_in",
      cableLengthFt: 10,
      busType: "ac_line",
      calculatedCurrentA: 30,
      recommendedFuseA: 40,
      recommendedCableAwg: "8",
      voltageDropV: 0.377,
      voltageDropPercent: 0.16,
      warnings: []
    },
    {
      id: "gen-l2",
      fromComponentId: "generator-source",
      fromTerminalId: "ac_l2",
      toComponentId: "generator-breaker",
      toTerminalId: "l2_in",
      cableLengthFt: 10,
      busType: "ac_line2",
      calculatedCurrentA: 30,
      recommendedFuseA: 40,
      recommendedCableAwg: "8",
      voltageDropV: 0.377,
      voltageDropPercent: 0.16,
      warnings: []
    },
    {
      id: "gen-breaker-inverter-l1",
      fromComponentId: "generator-breaker",
      fromTerminalId: "l1_out",
      toComponentId: "inverter",
      toTerminalId: "ac_gen_l1",
      cableLengthFt: 6,
      busType: "ac_line",
      calculatedCurrentA: 0,
      recommendedCableAwg: "8",
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: [],
      routePoints: [
        {
          x: 327.4,
          y: 290
        },
        {
          x: 11,
          y: 290
        }
      ],
      routeMode: "manual"
    },
    {
      id: "gen-breaker-inverter-l2",
      fromComponentId: "generator-breaker",
      fromTerminalId: "l2_out",
      toComponentId: "inverter",
      toTerminalId: "ac_gen_l2",
      cableLengthFt: 6,
      busType: "ac_line2",
      calculatedCurrentA: 0,
      recommendedCableAwg: "8",
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: [],
      routePoints: [
        {
          x: 352.6,
          y: 300
        },
        {
          x: 23,
          y: 300
        }
      ],
      routeMode: "manual"
    },
    {
      id: "gen-neutral",
      fromComponentId: "generator-source",
      fromTerminalId: "ac_n",
      toComponentId: "inverter",
      toTerminalId: "ac_gen_n",
      cableLengthFt: 10,
      busType: "ac_neutral",
      calculatedCurrentA: 30,
      recommendedCableAwg: "12",
      voltageDropV: 0.953,
      voltageDropPercent: 0.4,
      warnings: [],
      routePoints: [
        {
          x: 380,
          y: 16
        },
        {
          x: 380,
          y: 310
        },
        {
          x: 17,
          y: 310
        }
      ],
      routeMode: "manual"
    },
    {
      id: "load-l1",
      fromComponentId: "inverter",
      fromTerminalId: "ac_out_l1",
      toComponentId: "load-breaker",
      toTerminalId: "l1_in",
      cableLengthFt: 8,
      busType: "ac_line",
      calculatedCurrentA: 40,
      recommendedFuseA: 50,
      recommendedCableAwg: "10",
      voltageDropV: 0.639,
      voltageDropPercent: 0.27,
      warnings: [],
      routePoints: [
        {
          x: 59,
          y: 340
        },
        {
          x: 327.4,
          y: 340
        }
      ],
      routeMode: "manual"
    },
    {
      id: "load-l2",
      fromComponentId: "inverter",
      fromTerminalId: "ac_out_l2",
      toComponentId: "load-breaker",
      toTerminalId: "l2_in",
      cableLengthFt: 8,
      busType: "ac_line2",
      calculatedCurrentA: 40,
      recommendedFuseA: 50,
      recommendedCableAwg: "10",
      voltageDropV: 0.639,
      voltageDropPercent: 0.27,
      warnings: [],
      routePoints: [
        {
          x: 76,
          y: 330
        },
        {
          x: 352.6,
          y: 330
        }
      ],
      routeMode: "manual"
    },
    {
      id: "load-breaker-load-l1",
      fromComponentId: "load-breaker",
      fromTerminalId: "l1_out",
      toComponentId: "ac-load",
      toTerminalId: "ac_l1",
      cableLengthFt: 6,
      busType: "ac_line",
      calculatedCurrentA: 40,
      recommendedFuseA: 50,
      recommendedCableAwg: "10",
      voltageDropV: 0.48,
      voltageDropPercent: 0.2,
      warnings: []
    },
    {
      id: "load-breaker-load-l2",
      fromComponentId: "load-breaker",
      fromTerminalId: "l2_out",
      toComponentId: "ac-load",
      toTerminalId: "ac_l2",
      cableLengthFt: 6,
      busType: "ac_line2",
      calculatedCurrentA: 40,
      recommendedFuseA: 50,
      recommendedCableAwg: "10",
      voltageDropV: 0.48,
      voltageDropPercent: 0.2,
      warnings: []
    },
    {
      id: "load-neutral",
      fromComponentId: "inverter",
      fromTerminalId: "ac_out_n",
      toComponentId: "ac-load",
      toTerminalId: "ac_n",
      cableLengthFt: 8,
      busType: "ac_neutral",
      calculatedCurrentA: 40,
      recommendedCableAwg: "10",
      voltageDropV: 0.639,
      voltageDropPercent: 0.27,
      warnings: [],
      routePoints: [
        {
          x: 68,
          y: 350
        },
        {
          x: 300,
          y: 350
        },
        {
          x: 300,
          y: 536
        }
      ],
      routeMode: "manual"
    },
    {
      id: "conn-1782756072281-1214",
      fromComponentId: "bat-3",
      fromTerminalId: "dc_pos_1",
      toComponentId: "bat-2",
      toTerminalId: "dc_pos_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -270,
          y: 456
        },
        {
          x: -270,
          y: 410
        },
        {
          x: -70,
          y: 410
        },
        {
          x: -70,
          y: 470
        }
      ],
      routeMode: "manual",
      busType: "dc_pos",
      calculatedCurrentA: 200,
      recommendedCableAwg: "2/0",
      voltageDropV: 0.062,
      voltageDropPercent: 0.12,
      warnings: [],
      recommendedFuseA: 250
    },
    {
      id: "conn-1782756075224-1215",
      fromComponentId: "bat-2",
      fromTerminalId: "dc_pos_1",
      toComponentId: "bat-1",
      toTerminalId: "dc_pos_2",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -70,
          y: 456
        },
        {
          x: -70,
          y: 410
        },
        {
          x: 130,
          y: 410
        },
        {
          x: 130,
          y: 470
        }
      ],
      routeMode: "manual",
      busType: "dc_pos",
      calculatedCurrentA: 200,
      recommendedCableAwg: "2/0",
      voltageDropV: 0.062,
      voltageDropPercent: 0.12,
      warnings: [],
      recommendedFuseA: 250
    },
    {
      id: "conn-1782756113130-1217",
      fromComponentId: "inverter",
      fromTerminalId: "dc_neg",
      toComponentId: "bat-3",
      toTerminalId: "dc_neg_1",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -39,
          y: 380
        },
        {
          x: -450,
          y: 380
        },
        {
          x: -450,
          y: 456
        }
      ],
      routeMode: "manual",
      busType: "dc_neg",
      calculatedCurrentA: 250,
      recommendedCableAwg: "4/0",
      voltageDropV: 0.049,
      voltageDropPercent: 0.1,
      warnings: [],
      cableMode: "dynamic"
    },
    {
      id: "conn-1782756118122-1218",
      fromComponentId: "bat-3",
      fromTerminalId: "dc_neg_2",
      toComponentId: "bat-2",
      toTerminalId: "dc_neg_1",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -450,
          y: 470
        },
        {
          x: -450,
          y: 420
        },
        {
          x: -250,
          y: 420
        },
        {
          x: -250,
          y: 456
        }
      ],
      routeMode: "manual",
      busType: "dc_neg",
      calculatedCurrentA: 200,
      recommendedCableAwg: "2/0",
      voltageDropV: 0.062,
      voltageDropPercent: 0.12,
      warnings: []
    },
    {
      id: "conn-1782756120529-1219",
      fromComponentId: "bat-2",
      fromTerminalId: "dc_neg_2",
      toComponentId: "bat-1",
      toTerminalId: "dc_neg_1",
      cableLengthFt: 2,
      routePoints: [
        {
          x: -250,
          y: 470
        },
        {
          x: -250,
          y: 420
        },
        {
          x: -50,
          y: 420
        },
        {
          x: -50,
          y: 456
        }
      ],
      routeMode: "manual",
      busType: "dc_neg",
      calculatedCurrentA: 200,
      recommendedCableAwg: "2/0",
      voltageDropV: 0.062,
      voltageDropPercent: 0.12,
      warnings: []
    },
    {
      id: "conn-1782756352006-1221",
      fromComponentId: "bat-3",
      fromTerminalId: "port_lynk_2",
      toComponentId: "bat-2",
      toTerminalId: "port_lynk_1",
      cableLengthFt: 6,
      wireKind: "communication",
      busType: "communication",
      calculatedCurrentA: 0,
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: []
    },
    {
      id: "conn-1782756354050-1228",
      fromComponentId: "bat-2",
      fromTerminalId: "port_lynk_2",
      toComponentId: "bat-1",
      toTerminalId: "port_lynk_1",
      cableLengthFt: 6,
      wireKind: "communication",
      busType: "communication",
      calculatedCurrentA: 0,
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: []
    },
    {
      id: "conn-1782756356620-1241",
      fromComponentId: "bat-1",
      fromTerminalId: "can_out",
      toComponentId: "inverter",
      toTerminalId: "comm",
      cableLengthFt: 6,
      wireKind: "communication",
      routePoints: [
        {
          x: 86,
          y: 440
        },
        {
          x: 86,
          y: 370
        },
        {
          x: 40,
          y: 370
        }
      ],
      routeMode: "manual",
      busType: "communication",
      calculatedCurrentA: 0,
      voltageDropV: 0,
      voltageDropPercent: 0,
      warnings: []
    },
    {
      id: "conn-1782758516688-1621",
      fromComponentId: "comp-1782758496710-223",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758499526-398",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758518142-1640",
      fromComponentId: "comp-1782758499526-398",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758500854-585",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758538135-2956",
      fromComponentId: "comp-1782758514118-1494",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758508062-964",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758539166-2975",
      fromComponentId: "comp-1782758508062-964",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758496710-223",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758541111-2994",
      fromComponentId: "comp-1782758500854-585",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758512086-1271",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758549270-3205",
      fromComponentId: "comp-1782758544710-3018",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758544710-3016",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758550189-3224",
      fromComponentId: "comp-1782758544710-3016",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758544710-3013",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758551111-3243",
      fromComponentId: "comp-1782758544710-3013",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758544710-3014",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758552190-3262",
      fromComponentId: "comp-1782758544710-3014",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758544710-3015",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758553102-3281",
      fromComponentId: "comp-1782758544710-3015",
      fromTerminalId: "pv_pos",
      toComponentId: "comp-1782758544710-3017",
      toTerminalId: "pv_neg",
      cableLengthFt: 6,
      busType: "unknown",
      calculatedCurrentA: 12,
      recommendedCableAwg: "18",
      voltageDropV: 0.919,
      voltageDropPercent: 2.7,
      warnings: []
    },
    {
      id: "conn-1782758556655-3300",
      fromComponentId: "comp-1782758544710-3018",
      fromTerminalId: "pv_neg",
      toComponentId: "inverter",
      toTerminalId: "pv1_neg",
      cableLengthFt: 6,
      routePoints: [
        {
          x: -805,
          y: -70
        },
        {
          x: 120,
          y: -70
        },
        {
          x: 120,
          y: 187
        }
      ],
      routeMode: "manual",
      busType: "pv_neg",
      calculatedCurrentA: 12,
      recommendedCableAwg: "16",
      voltageDropV: 0.578,
      voltageDropPercent: 1.2,
      warnings: []
    },
    {
      id: "conn-1782758559215-3319",
      fromComponentId: "comp-1782758544710-3017",
      fromTerminalId: "pv_pos",
      toComponentId: "inverter",
      toTerminalId: "pv1_pos",
      cableLengthFt: 6,
      routePoints: [
        {
          x: -55,
          y: -80
        },
        {
          x: 130,
          y: -80
        },
        {
          x: 130,
          y: 174
        }
      ],
      routeMode: "manual",
      busType: "pv_pos",
      calculatedCurrentA: 12,
      recommendedCableAwg: "16",
      voltageDropV: 0.578,
      voltageDropPercent: 1.2,
      warnings: []
    },
    {
      id: "conn-1782758568431-3986",
      fromComponentId: "comp-1782758514118-1494",
      fromTerminalId: "pv_neg",
      toComponentId: "inverter",
      toTerminalId: "pv2_neg",
      cableLengthFt: 6,
      routePoints: [
        {
          x: -805,
          y: -210
        },
        {
          x: 150,
          y: -210
        },
        {
          x: 150,
          y: 161
        }
      ],
      routeMode: "manual",
      busType: "pv_neg",
      calculatedCurrentA: 12,
      recommendedCableAwg: "16",
      voltageDropV: 0.578,
      voltageDropPercent: 1.2,
      warnings: []
    },
    {
      id: "conn-1782758570759-4005",
      fromComponentId: "comp-1782758512086-1271",
      fromTerminalId: "pv_pos",
      toComponentId: "inverter",
      toTerminalId: "pv2_pos",
      cableLengthFt: 6,
      routePoints: [
        {
          x: 140,
          y: -260
        },
        {
          x: 140,
          y: 149
        }
      ],
      routeMode: "manual",
      busType: "pv_pos",
      calculatedCurrentA: 12,
      recommendedCableAwg: "16",
      voltageDropV: 0.578,
      voltageDropPercent: 1.2,
      warnings: []
    },
    {
      id: "conn-1782765880160-15",
      fromComponentId: "bat-1",
      fromTerminalId: "dc_pos_1",
      toComponentId: "comp-1782765880160-14",
      toTerminalId: "in",
      cableLengthFt: 1,
      routePoints: [
        {
          x: 130,
          y: 456
        },
        {
          x: 130,
          y: 380
        }
      ],
      busType: "dc_pos",
      calculatedCurrentA: 250,
      recommendedFuseA: 325,
      recommendedCableAwg: "4/0",
      voltageDropV: 0.025,
      voltageDropPercent: 0.05,
      warnings: []
    },
    {
      id: "conn-1782765880160-16",
      fromComponentId: "comp-1782765880160-14",
      fromTerminalId: "out",
      toComponentId: "inverter",
      toTerminalId: "dc_pos",
      cableLengthFt: 1,
      routePoints: [
        {
          x: -27,
          y: 380
        }
      ],
      busType: "dc_pos",
      calculatedCurrentA: 250,
      recommendedFuseA: 325,
      recommendedCableAwg: "4/0",
      voltageDropV: 0.025,
      voltageDropPercent: 0.05,
      warnings: []
    }
  ],
  annotations: []
};

export const SYSTEM_PRESETS: SystemPreset[] = [
  {
    id: 'simple-12v',
    name: 'Simple 12V Solar',
    description:
      'Small 12 V starter system slot for the final default library.',
    voltage: 12,
    tags: ['12V', 'Small', 'Solar'],
    system: SIMPLE_12V,
  },
  {
    id: 'full-12v',
    name: 'Full 12V Mobile',
    description:
      'Larger 12 V mobile power system slot for the final default library.',
    voltage: 12,
    tags: ['12V', 'Mobile', 'Full System'],
    system: FULL_12V,
  },
  {
    id: 'offgrid-48v',
    name: '48V Hybrid Off-Grid Cabin',
    description:
      'Three Discover Helios batteries in parallel, a Megarevo hybrid inverter, dual PV strings, and split-phase AC source/load placeholders.',
    voltage: 48,
    tags: ['48V', 'Cabin', 'Hybrid', 'Solar', 'Generator', 'Helios'],
    system: OFFGRID_48V,
  },
];

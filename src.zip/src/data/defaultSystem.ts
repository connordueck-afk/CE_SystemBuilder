import type { SystemDesign } from '../types/system';

const DEFAULT_ASSUMPTIONS: SystemDesign['assumptions'] = {
  inverterEfficiency: 0.92,
  defaultOemDiscountPercent: 30,
  defaultCableLengthFt: 6,
  maxVoltageDropPercent: 3,
  continuousLoadMultiplier: 1.25,
  batteryInterconnectMaxLengthFt: 3
};

export const DEFAULT_SYSTEM: SystemDesign = {
  id: "sys-default-48v-hybrid",
  name: "48V Hybrid Off-Grid Cabin",
  nominalVoltage: 48,
  assumptions: DEFAULT_ASSUMPTIONS,
  createdAt: "2026-06-29T00:00:00.000Z",
  updatedAt: "2026-06-29T00:00:00.000Z",
  components: [
    {
      id: "bat-1",
      productId: "discover-helios-ess-52-48-16000",
      label: "Helios ESS 1",
      quantity: 1,
      x: -520,
      y: 120,
      includeInBom: true,
      imageScale: 2
    },
    {
      id: "bat-2",
      productId: "discover-helios-ess-52-48-16000",
      label: "Helios ESS 2",
      quantity: 1,
      x: -520,
      y: 330,
      includeInBom: true,
      imageScale: 2
    },
    {
      id: "bat-3",
      productId: "discover-helios-ess-52-48-16000",
      label: "Helios ESS 3",
      quantity: 1,
      x: -520,
      y: 540,
      includeInBom: true,
      imageScale: 2
    },
    {
      id: "fuse-bat-1",
      productId: "fuse-class-t-225a",
      label: "Battery 1 Fuse",
      quantity: 1,
      x: -300,
      y: 100,
      rotationDeg: 270,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "fuse-bat-2",
      productId: "fuse-class-t-225a",
      label: "Battery 2 Fuse",
      quantity: 1,
      x: -300,
      y: 310,
      rotationDeg: 270,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "fuse-bat-3",
      productId: "fuse-class-t-225a",
      label: "Battery 3 Fuse",
      quantity: 1,
      x: -300,
      y: 520,
      rotationDeg: 270,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "bus-pos",
      productId: "dist-generic-busbar-5pt",
      label: "Positive Busbar",
      quantity: 1,
      x: -40,
      y: 250,
      includeInBom: true,
      busPolarity: "positive",
      dcNominalVoltage: 48,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "bus-neg",
      productId: "dist-generic-busbar-5pt",
      label: "Negative Busbar",
      quantity: 1,
      x: -40,
      y: 430,
      includeInBom: true,
      busPolarity: "negative",
      dcNominalVoltage: 48,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "negative",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "fuse-inverter",
      productId: "fuse-class-t-300a",
      label: "Main Inverter Fuse",
      quantity: 1,
      x: 160,
      y: 250,
      rotationDeg: 270,
      includeInBom: true,
      inferredConnectionKind: "dc_power",
      inferredPolarity: "positive",
      inferredVoltageClass: "dc_low_voltage"
    },
    {
      id: "inverter",
      productId: "megarevo-12kw-hybrid-inverter",
      label: "Megarevo Hybrid Inverter",
      quantity: 1,
      x: 440,
      y: 330,
      includeInBom: true
    },
    {
      id: "pv-string-1",
      productId: "custom-solar-array",
      label: "Custom PV Array 1",
      quantity: 1,
      x: -420,
      y: -560,
      includeInBom: false,
      customSolarArrayRatings: {
        vocV: 280,
        vmpV: 238,
        iscA: 12,
        impA: 10,
        powerW: 2800,
        description: "Example aggregate PV array; customer-supplied / existing array."
      }
    },
    {
      id: "pv-disconnect-1",
      productId: "generic-pv-disconnect",
      label: "PV1 Disconnect",
      quantity: 1,
      x: -80,
      y: -430,
      includeInBom: true
    },
    {
      id: "pv-string-2",
      productId: "custom-solar-array",
      label: "Custom PV Array 2",
      quantity: 1,
      x: 120,
      y: -560,
      includeInBom: false,
      customSolarArrayRatings: {
        vocV: 280,
        vmpV: 238,
        iscA: 12,
        impA: 10,
        powerW: 2800,
        description: "Example aggregate PV array; customer-supplied / existing array."
      }
    },
    {
      id: "pv-disconnect-2",
      productId: "generic-pv-disconnect",
      label: "PV2 Disconnect",
      quantity: 1,
      x: 240,
      y: -430,
      includeInBom: true
    },
    {
      id: "grid-source",
      productId: "generic-grid-source-240v",
      label: "AC Source",
      quantity: 1,
      x: 1020,
      y: 40,
      includeInBom: true
    },
    {
      id: "grid-breaker",
      productId: "breaker-ac-din-2p-63a",
      label: "Grid Input Breaker",
      quantity: 1,
      x: 820,
      y: 70,
      includeInBom: true
    },
    {
      id: "generator-source",
      productId: "generic-generator-source-240v",
      label: "Generator Source",
      quantity: 1,
      x: 1020,
      y: 310,
      includeInBom: true
    },
    {
      id: "generator-breaker",
      productId: "breaker-ac-din-2p-63a",
      label: "Generator Input Breaker",
      quantity: 1,
      x: 820,
      y: 300,
      includeInBom: true
    },
    {
      id: "load-breaker",
      productId: "breaker-ac-din-2p-50a",
      label: "Critical Loads Breaker",
      quantity: 1,
      x: 610,
      y: 650,
      includeInBom: true
    },
    {
      id: "ac-load",
      productId: "acc-ac-load-split-phase-240v",
      label: "AC Loads",
      quantity: 1,
      x: 830,
      y: 670,
      includeInBom: true
    }
  ],
  connections: [
    {
      id: "bat1-pos",
      fromComponentId: "bat-1",
      fromTerminalId: "dc_pos_1",
      toComponentId: "fuse-bat-1",
      toTerminalId: "in",
      cableLengthFt: 2
    },
    {
      id: "bat1-fuse-bus",
      fromComponentId: "fuse-bat-1",
      fromTerminalId: "out",
      toComponentId: "bus-pos",
      toTerminalId: "terminal_1",
      cableLengthFt: 3
    },
    {
      id: "bat2-pos",
      fromComponentId: "bat-2",
      fromTerminalId: "dc_pos_1",
      toComponentId: "fuse-bat-2",
      toTerminalId: "in",
      cableLengthFt: 2
    },
    {
      id: "bat2-fuse-bus",
      fromComponentId: "fuse-bat-2",
      fromTerminalId: "out",
      toComponentId: "bus-pos",
      toTerminalId: "terminal_2",
      cableLengthFt: 3
    },
    {
      id: "bat3-pos",
      fromComponentId: "bat-3",
      fromTerminalId: "dc_pos_1",
      toComponentId: "fuse-bat-3",
      toTerminalId: "in",
      cableLengthFt: 2
    },
    {
      id: "bat3-fuse-bus",
      fromComponentId: "fuse-bat-3",
      fromTerminalId: "out",
      toComponentId: "bus-pos",
      toTerminalId: "terminal_3",
      cableLengthFt: 3
    },
    {
      id: "bat1-neg",
      fromComponentId: "bat-1",
      fromTerminalId: "dc_neg_1",
      toComponentId: "bus-neg",
      toTerminalId: "terminal_1",
      cableLengthFt: 4
    },
    {
      id: "bat2-neg",
      fromComponentId: "bat-2",
      fromTerminalId: "dc_neg_1",
      toComponentId: "bus-neg",
      toTerminalId: "terminal_2",
      cableLengthFt: 4
    },
    {
      id: "bat3-neg",
      fromComponentId: "bat-3",
      fromTerminalId: "dc_neg_1",
      toComponentId: "bus-neg",
      toTerminalId: "terminal_3",
      cableLengthFt: 4
    },
    {
      id: "bus-pos-main-fuse",
      fromComponentId: "bus-pos",
      fromTerminalId: "terminal_4",
      toComponentId: "fuse-inverter",
      toTerminalId: "in",
      cableLengthFt: 3
    },
    {
      id: "main-fuse-inverter",
      fromComponentId: "fuse-inverter",
      fromTerminalId: "out",
      toComponentId: "inverter",
      toTerminalId: "dc_pos",
      cableLengthFt: 3
    },
    {
      id: "bus-neg-inverter",
      fromComponentId: "bus-neg",
      fromTerminalId: "terminal_4",
      toComponentId: "inverter",
      toTerminalId: "dc_neg",
      cableLengthFt: 4
    },
    {
      id: "pv1-pos",
      fromComponentId: "pv-string-1",
      fromTerminalId: "pv_pos",
      toComponentId: "pv-disconnect-1",
      toTerminalId: "in_pos",
      cableLengthFt: 20
    },
    {
      id: "pv1-neg",
      fromComponentId: "pv-string-1",
      fromTerminalId: "pv_neg",
      toComponentId: "pv-disconnect-1",
      toTerminalId: "in_neg",
      cableLengthFt: 20
    },
    {
      id: "pv1-disconnect-inverter-pos",
      fromComponentId: "pv-disconnect-1",
      fromTerminalId: "out_pos",
      toComponentId: "inverter",
      toTerminalId: "pv1_pos",
      cableLengthFt: 10
    },
    {
      id: "pv1-disconnect-inverter-neg",
      fromComponentId: "pv-disconnect-1",
      fromTerminalId: "out_neg",
      toComponentId: "inverter",
      toTerminalId: "pv1_neg",
      cableLengthFt: 10
    },
    {
      id: "pv2-pos",
      fromComponentId: "pv-string-2",
      fromTerminalId: "pv_pos",
      toComponentId: "pv-disconnect-2",
      toTerminalId: "in_pos",
      cableLengthFt: 20
    },
    {
      id: "pv2-neg",
      fromComponentId: "pv-string-2",
      fromTerminalId: "pv_neg",
      toComponentId: "pv-disconnect-2",
      toTerminalId: "in_neg",
      cableLengthFt: 20
    },
    {
      id: "pv2-disconnect-inverter-pos",
      fromComponentId: "pv-disconnect-2",
      fromTerminalId: "out_pos",
      toComponentId: "inverter",
      toTerminalId: "pv2_pos",
      cableLengthFt: 10
    },
    {
      id: "pv2-disconnect-inverter-neg",
      fromComponentId: "pv-disconnect-2",
      fromTerminalId: "out_neg",
      toComponentId: "inverter",
      toTerminalId: "pv2_neg",
      cableLengthFt: 10
    },
    {
      id: "grid-l1",
      fromComponentId: "grid-source",
      fromTerminalId: "ac_l1",
      toComponentId: "grid-breaker",
      toTerminalId: "l1_in",
      cableLengthFt: 10
    },
    {
      id: "grid-l2",
      fromComponentId: "grid-source",
      fromTerminalId: "ac_l2",
      toComponentId: "grid-breaker",
      toTerminalId: "l2_in",
      cableLengthFt: 10
    },
    {
      id: "grid-breaker-inverter-l1",
      fromComponentId: "grid-breaker",
      fromTerminalId: "l1_out",
      toComponentId: "inverter",
      toTerminalId: "ac_grid_l1",
      cableLengthFt: 6
    },
    {
      id: "grid-breaker-inverter-l2",
      fromComponentId: "grid-breaker",
      fromTerminalId: "l2_out",
      toComponentId: "inverter",
      toTerminalId: "ac_grid_l2",
      cableLengthFt: 6
    },
    {
      id: "grid-neutral",
      fromComponentId: "grid-source",
      fromTerminalId: "ac_n",
      toComponentId: "inverter",
      toTerminalId: "ac_grid_n",
      cableLengthFt: 10
    },
    {
      id: "gen-l1",
      fromComponentId: "generator-source",
      fromTerminalId: "ac_l1",
      toComponentId: "generator-breaker",
      toTerminalId: "l1_in",
      cableLengthFt: 10
    },
    {
      id: "gen-l2",
      fromComponentId: "generator-source",
      fromTerminalId: "ac_l2",
      toComponentId: "generator-breaker",
      toTerminalId: "l2_in",
      cableLengthFt: 10
    },
    {
      id: "gen-breaker-inverter-l1",
      fromComponentId: "generator-breaker",
      fromTerminalId: "l1_out",
      toComponentId: "inverter",
      toTerminalId: "ac_gen_l1",
      cableLengthFt: 6
    },
    {
      id: "gen-breaker-inverter-l2",
      fromComponentId: "generator-breaker",
      fromTerminalId: "l2_out",
      toComponentId: "inverter",
      toTerminalId: "ac_gen_l2",
      cableLengthFt: 6
    },
    {
      id: "gen-neutral",
      fromComponentId: "generator-source",
      fromTerminalId: "ac_n",
      toComponentId: "inverter",
      toTerminalId: "ac_gen_n",
      cableLengthFt: 10
    },
    {
      id: "load-l1",
      fromComponentId: "inverter",
      fromTerminalId: "ac_out_l1",
      toComponentId: "load-breaker",
      toTerminalId: "l1_in",
      cableLengthFt: 8
    },
    {
      id: "load-l2",
      fromComponentId: "inverter",
      fromTerminalId: "ac_out_l2",
      toComponentId: "load-breaker",
      toTerminalId: "l2_in",
      cableLengthFt: 8
    },
    {
      id: "load-breaker-load-l1",
      fromComponentId: "load-breaker",
      fromTerminalId: "l1_out",
      toComponentId: "ac-load",
      toTerminalId: "ac_l1",
      cableLengthFt: 6
    },
    {
      id: "load-breaker-load-l2",
      fromComponentId: "load-breaker",
      fromTerminalId: "l2_out",
      toComponentId: "ac-load",
      toTerminalId: "ac_l2",
      cableLengthFt: 6
    },
    {
      id: "load-neutral",
      fromComponentId: "inverter",
      fromTerminalId: "ac_out_n",
      toComponentId: "ac-load",
      toTerminalId: "ac_n",
      cableLengthFt: 8
    }
  ],
  annotations: []
};

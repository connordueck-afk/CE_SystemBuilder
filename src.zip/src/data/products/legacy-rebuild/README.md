# Legacy rebuild workspace

This folder is for rebuilt legacy product files that are still being reviewed
and should not be loaded into the active catalog yet.

Processing order:

1. Follow the legacy file list in sorted path order.
2. Rebuild one product at a time into the matching subfolder here.
3. Validate each rebuilt product before moving to the next one.

Current status:

- Started: 2026-06-27
- Next product: `src/data/products/legacy/batteries/bat-vic-smart-12-100.ts`
- Active catalog impact: none

import type { Product } from '../../../../types/system';

const product: Product = {
  id: "smartshunt-500",
  manufacturer: "Victron",
  name: "SmartShunt 500A/50mV",
  productType: "monitor",
  category: "Monitoring",
  maxCurrentA: 500,
  msrpUsd: 123,
  description: "Victron SmartShunt 500A Bluetooth battery monitor with integrated 500A/50mV shunt.",
  partNumber: "SHU050150050",
  source: "Victron 2025",
  dataQuality: "partial",
  notes: "Simplified as a 500A negative-leg pass-through shunt with VE.Direct communication.",
  width: 100,
  height: 50,
  terminalGroups: [
    { id: "shunt_batt_side", portId: "main", label: "Battery Minus", groupType: "power_conductor", kind: "dc_power", polarity: "negative", internallyCommon: false, maxCurrentA: 500 },
    { id: "shunt_bus_side", portId: "main", label: "System Minus", groupType: "power_conductor", kind: "dc_power", polarity: "negative", internallyCommon: false, maxCurrentA: 500 },
    { id: "ve_direct_iface", portId: "ve_direct", label: "VE.Direct Interface", groupType: "communication_interface", internallyCommon: false },
  ],
  terminals: [
    {
      id: "shunt_pos",
      terminalGroupId: "shunt_batt_side",
      label: "BATT-",
      polarity: "negative",
      role: "pass_through",
      direction: "bidirectional",
      voltageClass: "dc_low_voltage",
      side: "left",
      offsetX: -42,
      offsetY: 13,
      maxCurrentA: 500,
      connector: {
        kind: "stud",
        holeSize: "M10"
      },
      notes: "Battery negative side of the 500A shunt.",
      portId: "main"
    },
    {
      id: "shunt_neg",
      terminalGroupId: "shunt_bus_side",
      label: "SYS-",
      polarity: "negative",
      role: "pass_through",
      direction: "bidirectional",
      voltageClass: "dc_low_voltage",
      side: "right",
      offsetX: 42,
      offsetY: 13,
      maxCurrentA: 500,
      connector: {
        kind: "stud",
        holeSize: "M10"
      },
      notes: "System/load negative side of the 500A shunt.",
      portId: "main"
    },
    {
      id: "ve_direct",
      terminalGroupId: "ve_direct_iface",
      label: "VE.Direct",
      role: "bidirectional",
      side: "top",
      offsetX: 0,
      offsetY: -25,
      portId: "ve_direct"
    }
  ],
  communicationPorts: [
    {
      id: "ve_direct",
      name: "VE.Direct",
      connectorType: "VE.Direct",
      supportedProtocols: [
        "VE.Direct"
      ],
      configuredProtocol: "VE.Direct"
    }
  ],
  ports: [
    {
      id: "main",
      kind: "dc",
      topology: "pass_through",
      label: "Main",
      voltageClass: "dc_low_voltage",
      maxCurrentA: 500
    },
    {
      id: "ve_direct",
      kind: "comm",
      label: "VE.Direct",
      topology: "pass_through"
    }
  ]
};

export default product;

import type { Product } from '../../../../types/system';

const product: Product = {
  id: "generic-generator-source",
  manufacturer: "Generic",
  name: "Generator Source",
  productType: "shorePowerInlet",
  category: "AC Equipment",
  continuousPowerW: 3000,
  msrpUsd: 0,
  description: "Generic AC generator source placeholder",
  source: "User",
  dataQuality: "placeholder",
  width: 90,
  height: 64,
  terminalGroups: [
    { id: "ac_out_l", portId: "ac_out", label: "AC Output Line", groupType: "power_conductor", kind: "ac_power", polarity: "line", internallyCommon: false },
    { id: "ac_out_n", portId: "ac_out", label: "AC Output Neutral", groupType: "power_conductor", kind: "ac_power", polarity: "neutral", internallyCommon: false },
  ],
  terminals: [
    {
      id: "ac_l",
      terminalGroupId: "ac_out_l",
      label: "L",
      polarity: "line",
      role: "source",
      voltageClass: "ac_120v",
      side: "right",
      offsetX: 45,
      offsetY: -10,
      phases: 1,
      portId: "ac_out"
    },
    {
      id: "ac_n",
      terminalGroupId: "ac_out_n",
      label: "N",
      polarity: "neutral",
      role: "source",
      voltageClass: "ac_120v",
      side: "right",
      offsetX: 45,
      offsetY: 10,
      portId: "ac_out"
    }
  ],
  ports: [
    {
      id: "ac_out",
      kind: "ac",
      topology: "two_pole",
      label: "AC Output",
      voltageClass: "ac_120v",
      nominalVoltageV: 120,
      maxPowerW: 3000
    }
  ]
};

export default product;

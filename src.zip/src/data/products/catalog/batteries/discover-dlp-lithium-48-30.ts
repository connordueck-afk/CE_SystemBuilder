import type { Product } from '../../../../types/system';

const product: Product = {
  id: "discover-dlp-lithium-48-30",
  manufacturer: "Discover Battery",
  name: "DLP-GC2 51.2V/30Ah",
  productType: "battery",
  category: "Batteries",
  nominalVoltage: 48,
  capacityWh: 1536,
  maxCurrentA: 30,
  msrpUsd: 1250,
  description: "Discover DLP-GC2 battery 51.2V/30Ah with CAN communication",
  partNumber: "DLP-GC2-48V",
  productUrl: "https://www.cdnrg.com/products/dlp-gc2-48v",
  source: "Discover Battery 2025",
  notes: "Placeholder pricing/specs.",
  dataQuality: "partial",
  width: 92,
  height: 98,
  terminals: [
    {
      id: "dc_pos",
      label: "+",
      side: "top",
      offsetX: 22,
      offsetY: -45,
      maxCurrentA: 30,
      connector: {
        kind: "stud",
        holeSize: "M6"
      },
      terminalGroupId: "dc_pos",
      notes: "DC positive terminal. Requires overcurrent protection (fuse/breaker) on the positive conductor."
    },
    {
      id: "dc_neg",
      label: "-",
      side: "top",
      offsetX: -26,
      offsetY: -45,
      maxCurrentA: 30,
      connector: {
        kind: "stud",
        holeSize: "M6"
      },
      terminalGroupId: "dc_neg",
      notes: "DC negative terminal."
    },
    {
      id: "terminal_aebus",
      label: "AEBus",
      side: "top",
      offsetX: 0,
      offsetY: -45,
      terminalGroupId: "comm_aebus"
    }
  ],
  ports: [
    {
      id: "dc",
      kind: "dc",
      topology: "two_pole",
      label: "DC",
      nominalVoltageV: 51.2,
      voltageClass: "dc_low_voltage",
      maxCurrentA: 30,
      role: "bidirectional",
      direction: "bidirectional"
    },
    {
      id: "port_lynk",
      label: "AEBus",
      kind: "comm",
      topology: "two_pole",
      role: "bidirectional",
      direction: "bidirectional"
    }
  ],
  terminalGroups: [
    {
      id: "dc_pos",
      portId: "dc",
      label: "DC Positive",
      groupType: "power_conductor",
      polarity: "positive",
      internallyCommon: true,
      maxCurrentA: 30,
      requiresOvercurrentProtection: true,
      notes: "Battery positive conductor group."
    },
    {
      id: "dc_neg",
      portId: "dc",
      label: "DC Negative",
      groupType: "power_conductor",
      polarity: "negative",
      internallyCommon: true,
      maxCurrentA: 30,
      notes: "Battery negative conductor group."
    },
    {
      id: "comm_aebus",
      portId: "port_lynk",
      groupType: "communication_interface",
      internallyCommon: false,
      label: "AEBus"
    }
  ],
  batteryRatings: {
    nominalVoltageV: 51.2,
    capacityAh: 30,
    capacityWh: 1536,
    capacityKwh: 1.54,
    maxDischargeCurrentA: 30,
    chemistry: "LiFePO4",
    communicationInterfaces: [
      "CAN"
    ],
    hasInternalBms: true,
    seriesAllowed: false,
    parallelAllowed: true
  },
  communicationPorts: [
    {
      id: "terminal_aebus",
      name: "AEBus",
      connectorType: "M12",
      supportedProtocols: [],
      gender: "male"
    }
  ]
};

export default product;

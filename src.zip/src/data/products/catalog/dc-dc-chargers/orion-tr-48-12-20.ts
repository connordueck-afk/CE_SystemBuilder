import type { Product } from '../../../../types/system';

const product: Product = {
  id: "orion-tr-48-12-20",
  manufacturer: "Victron",
  name: "Orion-Tr Smart 48/12-20A Isolated",
  productType: "dc_dc_charger",
  category: "Charging",
  nominalVoltage: 12,
  maxCurrentA: 20,
  continuousPowerW: 240,
  msrpUsd: 196,
  description: "Victron Orion-Tr Smart 48V/12V-20A isolated DC-DC charger with Bluetooth.",
  partNumber: "ORI481224120",
  source: "Victron 2025",
  dataQuality: "partial",
  width: 86,
  height: 80,
  terminalGroups: [
    { id: "in_pos", portId: "input", label: "Input Positive", groupType: "power_conductor", kind: "dc_power", polarity: "positive", internallyCommon: false },
    { id: "in_neg", portId: "input", label: "Input Negative", groupType: "power_conductor", kind: "dc_power", polarity: "negative", internallyCommon: false },
    { id: "out_pos", portId: "output", label: "Output Positive", groupType: "power_conductor", kind: "dc_power", polarity: "positive", internallyCommon: false, maxCurrentA: 20 },
    { id: "out_neg", portId: "output", label: "Output Negative", groupType: "power_conductor", kind: "dc_power", polarity: "negative", internallyCommon: false, maxCurrentA: 20 },
  ],
  terminals: [
    {
      id: "in_pos",
      terminalGroupId: "in_pos",
      portId: "input",
      label: "In+",
      polarity: "positive",
      role: "sink",
      direction: "input",
      voltageClass: "dc_low_voltage",
      side: "bottom",
      offsetX: -16,
      offsetY: 24,
      requiresOvercurrentProtection: true,
      connector: {
        kind: "screw_terminal"
      },
      notes: "DC input positive. Fuse required on input positive conductor."
    },
    {
      id: "in_neg",
      terminalGroupId: "in_neg",
      portId: "input",
      label: "In-",
      polarity: "negative",
      role: "sink",
      direction: "input",
      voltageClass: "dc_low_voltage",
      side: "bottom",
      offsetX: -5,
      offsetY: 24,
      connector: {
        kind: "screw_terminal"
      },
      notes: "DC input negative."
    },
    {
      id: "out_pos",
      terminalGroupId: "out_pos",
      portId: "output",
      label: "Out+",
      polarity: "positive",
      role: "source",
      direction: "output",
      voltageClass: "dc_low_voltage",
      side: "bottom",
      offsetX: 5,
      offsetY: 24,
      requiresOvercurrentProtection: true,
      maxCurrentA: 20,
      connector: {
        kind: "screw_terminal"
      },
      notes: "DC output positive. Fuse required on output positive conductor."
    },
    {
      id: "out_neg",
      terminalGroupId: "out_neg",
      portId: "output",
      label: "Out-",
      polarity: "negative",
      role: "source",
      direction: "output",
      voltageClass: "dc_low_voltage",
      side: "bottom",
      offsetX: 16,
      offsetY: 24,
      maxCurrentA: 20,
      connector: {
        kind: "screw_terminal"
      },
      notes: "DC output negative."
    }
  ],
  dcDcChargerRatings: {
    inputVoltageMinV: 36,
    inputVoltageMaxV: 70,
    outputVoltageV: 12,
    outputCurrentA: 20,
    outputPowerW: 240,
    isolated: true
  },
  ports: [
    {
      id: "input",
      kind: "dc",
      topology: "two_pole",
      label: "Input",
      voltageClass: "dc_low_voltage",
      nominalVoltageV: 48,
      voltageMinV: 36,
      voltageMaxV: 70,
      maxPowerW: 240
    },
    {
      id: "output",
      kind: "dc",
      topology: "two_pole",
      label: "Output",
      voltageClass: "dc_low_voltage",
      nominalVoltageV: 12,
      maxCurrentA: 20,
      maxPowerW: 240
    }
  ]
};

export default product;

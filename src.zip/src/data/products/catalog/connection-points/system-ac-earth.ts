import type { Product } from '../../../../types/system';

const product: Product = {
  id: "system-ac-earth",
  manufacturer: "System",
  name: "AC Earth",
  productType: "connection_point",
  category: "Connection Points",
  description: "AC protective earth / grounding connection point.",
  isVirtual: true,
  isBOMItem: false,
  msrpUsd: 0,
  width: 60,
  height: 60,
  terminalGroups: [
    { id: "earth_gnd", portId: "ground", label: "AC Earth Ground", groupType: "ground_reference", kind: "chassis_ground", internallyCommon: false },
  ],
  terminals: [
    {
      id: "earth",
      terminalGroupId: "earth_gnd",
      label: "AC Earth",
      role: "bus",
      side: "top",
      offsetX: 0,
      offsetY: -30,
      portId: "ground"
    }
  ],
  ports: [
    {
      id: "ground",
      kind: "ground",
      topology: "two_pole",
      label: "Ground"
    }
  ]
};

export default product;

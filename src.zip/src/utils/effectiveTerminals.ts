import type { ConnectionPolarity, Product, SystemComponent, TerminalDefinition, EffectiveTerminal, BusPolarity } from '../types/system';
import { inferTerminalDirection } from './terminalDirection';
import { getTerminalPortId, terminalKind, terminalMaxCurrentA, terminalVoltageClass } from './portSpecs';

export function isGenericBusbar(product: Product): boolean {
  return product.productType === 'busbar' && product.manufacturer === 'Generic';
}

export function isPvBranchConnector(product: Product): boolean {
  return product.productType === 'solar_combiner' && product.category === 'Connectors';
}

export function isDynamicSingleConductorProduct(product: Product): boolean {
  if (isPvBranchConnector(product) || isGenericBusbar(product)) return true;
  if (['fuse', 'breaker', 'dcDisconnect', 'relay', 'contactor'].includes(product.productType)) {
    const powerTerminals = product.terminals.filter((terminal) => ['dc_power', 'pv_power'].includes(terminalKind(product, terminal)));
    if (powerTerminals.length < 2) return false;
    return new Set(powerTerminals.map((terminal) => terminal.polarity).filter(Boolean)).size <= 1;
  }

  const description = `${product.name} ${product.description ?? ''}`.toLowerCase();
  if (product.productType === 'monitor' && description.includes('shunt')) {
    const powerTerminals = product.terminals.filter((terminal) => terminalKind(product, terminal) === 'dc_power');
    return powerTerminals.length >= 2;
  }

  return false;
}

export function effectiveBusPolarity(component: SystemComponent): BusPolarity {
  return component.busPolarity ?? 'positive';
}

function polaritySuffix(polarity: ConnectionPolarity | undefined): string {
  if (polarity === 'positive') return '+';
  if (polarity === 'negative') return '-';
  if (polarity === 'line') return ' L';
  if (polarity === 'neutral') return ' N';
  if (polarity === 'ground') return ' G';
  return '';
}

function electricalTypeFor(kind: TerminalDefinition['kind'] | undefined, polarity: ConnectionPolarity | undefined): TerminalDefinition['electricalType'] {
  if (kind === 'pv_power') return polarity === 'negative' ? 'pv_neg' : polarity === 'positive' ? 'pv_pos' : undefined;
  if (kind === 'dc_power') return polarity === 'negative' ? 'dc_neg' : polarity === 'positive' ? 'dc_pos' : undefined;
  if (kind === 'ac_power') return 'ac';
  return undefined;
}

export function getEffectiveTerminals(product: Product, component?: SystemComponent): EffectiveTerminal[] {
  if (component && isPvBranchConnector(product)) {
    const polarity = component.inferredPolarity ?? component.busPolarity;
    const isAssigned = polarity === 'positive' || polarity === 'negative';
    const isPositive = polarity !== 'negative';
    const electricalType = isAssigned ? (isPositive ? 'pv_pos' : 'pv_neg') : undefined;
    const labelSuffix = isAssigned ? (isPositive ? '+' : '-') : '';

    return product.terminals.map((terminal) => {
      const portId = getTerminalPortId(product, terminal);
      const isOutput = terminal.id === 'out';
      const index = terminal.id.match(/^in_(\d+)$/)?.[1];
      const effectiveTerminal: EffectiveTerminal = {
        ...terminal,
        portId,
        label: isOutput ? `Out${labelSuffix}` : `In ${index ?? ''}${labelSuffix}`,
        electricalType,
        kind: 'pv_power',
        polarity: isAssigned ? polarity : undefined,
        role: 'bus',
        direction: 'bidirectional',
        voltageClass: 'pv_high_voltage',
        maxCurrentA: terminalMaxCurrentA(product, terminal),
      };

      return withEffectiveTerminalDirection(effectiveTerminal);
    });
  }

  if (component && isDynamicSingleConductorProduct(product) && isGenericBusbar(product)) {
    const kind = component.inferredConnectionKind;
    const polarity = component.inferredPolarity;
    const isAssigned = kind != null && polarity != null;
    const suffix = polaritySuffix(polarity);

    return product.terminals.map((terminal, index) => {
      const portId = getTerminalPortId(product, terminal);
      const effectiveTerminal: EffectiveTerminal = {
        ...terminal,
        portId,
        label: isAssigned ? `${suffix}${index + 1}` : `T${index + 1}`,
        electricalType: isAssigned ? electricalTypeFor(kind, polarity) : undefined,
        kind: isAssigned ? kind : 'dc_power',
        polarity: isAssigned ? polarity : undefined,
        role: 'bus',
        direction: 'bidirectional',
        voltageClass: isAssigned ? component.inferredVoltageClass ?? terminal.voltageClass : terminal.voltageClass,
        maxCurrentA: terminalMaxCurrentA(product, terminal),
      };

      return withEffectiveTerminalDirection(effectiveTerminal);
    });
  }

  if (component && isDynamicSingleConductorProduct(product)) {
    const kind = component.inferredConnectionKind;
    const polarity = component.inferredPolarity;
    const isAssigned = kind != null && polarity != null;
    const suffix = polaritySuffix(polarity);

    return product.terminals.map((terminal) => {
      const portId = getTerminalPortId(product, terminal);
      const resolvedKind = terminalKind(product, terminal);
      if (!['dc_power', 'pv_power', 'ac_power'].includes(resolvedKind)) {
        return withEffectiveTerminalDirection({ ...terminal, portId, kind: resolvedKind });
      }

      const effectiveTerminal: EffectiveTerminal = {
        ...terminal,
        portId,
        label: isAssigned ? `${terminal.id.startsWith('out') ? 'Out' : 'In'}${suffix}` : terminal.label.replace(/[+\-]$/, ''),
        electricalType: isAssigned ? electricalTypeFor(kind, polarity) : undefined,
        kind: isAssigned ? kind : resolvedKind,
        polarity: isAssigned ? polarity : undefined,
        role: terminal.role === 'sense' ? 'sense' : 'pass_through',
        voltageClass: isAssigned ? component.inferredVoltageClass ?? terminal.voltageClass : terminal.voltageClass,
        maxCurrentA: terminalMaxCurrentA(product, terminal),
      };

      return withEffectiveTerminalDirection(effectiveTerminal);
    });
  }

  if (!component || !isGenericBusbar(product)) {
    // Normal path: ownership of resolved specs is layered —
    //   - kind / voltageClass: port-authoritative (terminal fallback during migration)
    //   - polarity + per-pole protection (OCP / disconnect / fuse): terminal-group-
    //     authoritative (terminal fallback)
    //   - connector / placement / role: stay on the terminal
    // Each falls back to the terminal's own field so legacy products are unchanged.
    const groupsById = new Map((product.terminalGroups ?? []).map((g) => [g.id, g]));
    return product.terminals.map((terminal) => {
      const group = terminal.terminalGroupId ? groupsById.get(terminal.terminalGroupId) : undefined;
      const portId = getTerminalPortId(product, terminal);
      return withEffectiveTerminalDirection({
        ...terminal,
        portId,
        kind: terminalKind(product, terminal),
        voltageClass: terminalVoltageClass(product, terminal),
        maxCurrentA: terminalMaxCurrentA(product, terminal),
        polarity: group?.polarity ?? terminal.polarity,
        requiresOvercurrentProtection: group?.requiresOvercurrentProtection ?? terminal.requiresOvercurrentProtection,
        requiresDisconnect: group?.requiresDisconnect ?? terminal.requiresDisconnect,
        recommendedFuseA: group?.recommendedFuseA ?? terminal.recommendedFuseA,
        maxFuseA: group?.maxFuseA ?? terminal.maxFuseA,
      });
    });
  }

  const polarity = effectiveBusPolarity(component);
  const electricalType = polarity === 'positive' ? 'dc_pos' : 'dc_neg';
  const labelPrefix = polarity === 'positive' ? '+' : 'G';

  return product.terminals.map((terminal, index) => {
    const portId = getTerminalPortId(product, terminal);
    const effectiveTerminal: EffectiveTerminal = {
      ...terminal,
      portId,
      label: `${labelPrefix}${index + 1}`,
      electricalType,
      kind: 'dc_power',
      polarity,
      role: 'bus',
      direction: 'bidirectional',
      voltageClass: 'dc_low_voltage',
      maxCurrentA: terminalMaxCurrentA(product, terminal),
    };

    return withEffectiveTerminalDirection(effectiveTerminal);
  });
}

export function getEffectiveTerminal(
  product: Product,
  terminalId: string,
  component?: SystemComponent
): EffectiveTerminal | undefined {
  return getEffectiveTerminals(product, component).find((terminal) => terminal.id === terminalId);
}

export function withEffectiveTerminalDirection<T extends TerminalDefinition>(terminal: T): T {
  return { ...terminal, direction: inferTerminalDirection(terminal) };
}
